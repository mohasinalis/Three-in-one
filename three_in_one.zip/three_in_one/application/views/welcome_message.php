<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Welcome to CodeIgniter</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

    </head>
    <body>


        <a href="http://localhost/three_in_one/hierarchy" class="btn btn-info" role="button">Hierarchy</a>
        <a href="http://localhost/three_in_one/upload_excel" class="btn btn-info" role="button">Upload Excel</a>
        <a href="http://localhost/three_in_one/uploadcsv" class="btn btn-info" role="button">Upload CSV</a>

    </body>
</html>