<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Uploadcsv extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Welcome_model', 'welcome');
    }

    public function index() {
        $data['view_data'] = $this->welcome->view_data();
        $this->load->view('csvimport', $data);
    }

    //////////////////Import subscriber emails ////////////////////////////////
    public function importbulkemail() {
        $this->load->view('excelimport');
    }

    public function import() {
        if (isset($_POST["import"])) {
            $filename = $_FILES["file"]["tmp_name"];
//            $get_name = $_FILES['file']['name'];                       // file is a your post image name
//            substr("$get_name",-4);
            if ($_FILES["file"]["size"] > 0) {
                $file = fopen($filename, "r");
                $i = 0;
                while (($importdata = fgetcsv($file, 10000, ",")) !== FALSE) {
                    $data[] = array(
                        'id' => trim(utf8_encode($importdata[0])),
                        'subcat_name' => trim(utf8_encode($importdata[1])),
                        'subcat_img' => trim(utf8_encode($importdata[2])),
                        'cat_id' => trim(utf8_encode($importdata[3])),
                    );                    
                    $i++;
                }
              //  print_r($data); die;
                $insert = $this->welcome->insert_excel_CSV($data);
                fclose($file);
                $this->session->set_flashdata('message', 'Data are imported successfully..');
                redirect('uploadcsv/index');
            } else {
                $this->session->set_flashdata('message', 'Something went wrong..');
                redirect('uploadcsv/index');
            }
        }
    }
   

   
/////////////////////////////////Import subscriber emails ////////////////////////////////
}
