<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Upload_excel extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Welcome_model', 'welcome');
    }

    public function index() {
        $data['view_data'] = $this->welcome->view_data();
        $this->load->view('excelimport', $data);
    }

    //////////////////Import subscriber emails ////////////////////////////////
    public function importbulkemail() {
        $this->load->view('excelimport');
    }

    public function import() {
        require_once APPPATH . 'third_party/excel/Classes/PHPExcel.php';
        $tmpfname = $_FILES["result_file"]["tmp_name"];
        $excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
        $excelObj = $excelReader->load($tmpfname);
        $worksheet = $excelObj->getSheet(0);
        $lastRow = $worksheet->getHighestRow();


        if (!empty($lastRow)) {
            for ($row = 1; $row <= $lastRow; $row++) {

                $data[] = array(
                    "id" => $worksheet->getCell('A' . $row)->getValue(),
                    "subcat_name" => $worksheet->getCell('B' . $row)->getValue(),
                    "subcat_img" => $worksheet->getCell('C' . $row)->getValue(),
                    "cat_id" => $worksheet->getCell('D' . $row)->getValue(),
                );
            }
            $insert = $this->welcome->insert_excel_CSV($data);
            $this->session->set_flashdata('message', 'Data are imported successfully..');
            redirect('upload_excel/index');
        } else {
            $this->session->set_flashdata('message', 'Something went wrong..');
            redirect('upload_excel/index');
        }
    }

}
