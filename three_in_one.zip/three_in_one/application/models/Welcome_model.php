<?php

class Welcome_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function insert_excel_CSV($data) {
        $this->db->insert_batch('sub_category', $data);
        return TRUE;
    }

    public function view_data() {
        $query = $this->db->query("SELECT *
                                 FROM sub_category");
        return $query->result_array();
    }
    

}
